$(function () {
    $('form').submit(function () {
        // md5加密
        $('#password').val(md5($('#password').val()))
    })
});